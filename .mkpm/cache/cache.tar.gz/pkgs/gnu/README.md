# mkpm-gnu

> add gnu commands to makefiles
