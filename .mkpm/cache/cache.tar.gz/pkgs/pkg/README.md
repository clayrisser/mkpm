# mkpm-pkg

> create packages using make
